import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  define:{
    global: 'globalThis',
  },
  server: {
    port: 3000,
    host: true, // expose sur 0.0.0.0 → accessible depuis d'autres machines
    proxy: {
      '/api': {
        target: 'http://localhost:8080/tusmo-0.0.1-SNAPSHOT',
        changeOrigin: true,
      },
      '/ws': {
        target: 'http://localhost:8080/tusmo-0.0.1-SNAPSHOT',
        changeOrigin: true,
        ws: true,
      },
    },
  },
})
